SSID = "ssid of your network"
PASSWORD = "pass key to your network"