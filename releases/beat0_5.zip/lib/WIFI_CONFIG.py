SSID = "Your SSID"
PASSWORD = "Your password"